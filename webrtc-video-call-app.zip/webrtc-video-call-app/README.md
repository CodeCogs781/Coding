# WebRTC Video Call App

A Pen created on CodePen.

Original URL: [https://codepen.io/mayurbirle/pen/eYgPvVp](https://codepen.io/mayurbirle/pen/eYgPvVp).

A video calling app using WebRTC.  
Install PWA -> https://crater-test-app.web.app/